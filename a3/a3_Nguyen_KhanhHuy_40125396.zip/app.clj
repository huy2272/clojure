(ns app
  (:require [db])
  (:require [menu]))

(menu/main-menu)